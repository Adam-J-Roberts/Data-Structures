#include <iostream>
#include <iomanip> 
#include <ctime>
#include <chrono>
#include <ratio>
#include <fstream>
#include "Node.h"
#include "LinkedList.h"


using namespace std::chrono;

int main()
{
	srand(time(NULL));
	int count = 1;																//times function will get run
	
	ofstream outfile;                                                           //starting my off stream
	outfile.open ("project_34.txt");											//Creating file to save too


	/*
	LinkedList<int> a(NULL, NULL, 1, false);														//Innitializing Array
	LinkedList<int> b(NULL, NULL, 1, false);
	LinkedList<int> c(NULL, NULL, 1, false);
	LinkedList<int> d(NULL, NULL, 1, false);
	LinkedList<int> e(NULL, NULL, 1, false);
	LinkedList<int> f(NULL, NULL, 1, false);
	*/
	/*
	LinkedList<int> a(NULL, NULL, 1, true);														//Innitializing Array
	LinkedList<int> b(NULL, NULL, 1, true);
	LinkedList<int> c(NULL, NULL, 1, true);
	LinkedList<int> d(NULL, NULL, 1, true);
	LinkedList<int> e(NULL, NULL, 1, true);
	LinkedList<int> f(NULL, NULL, 1, true);
	*/
	/*
	LinkedList<int> a(NULL, NULL, 2, false);														//Innitializing Array
	LinkedList<int> b(NULL, NULL, 2, false);
	LinkedList<int> c(NULL, NULL, 2, false);
	LinkedList<int> d(NULL, NULL, 2, false);
	LinkedList<int> e(NULL, NULL, 2, false);
	LinkedList<int> f(NULL, NULL, 2, false);
	*/

	LinkedList<int> a(NULL, NULL, 2, true);														//Innitializing Array
	LinkedList<int> b(NULL, NULL, 2, true);
	LinkedList<int> c(NULL, NULL, 2, true);
	LinkedList<int> d(NULL, NULL, 2, true);
	LinkedList<int> e(NULL, NULL, 2, true);
	LinkedList<int> f(NULL, NULL, 2, true);
		
		
																	
				//  PREPEND     //
	outfile << "Prepend" << endl;	
	
	for (int j = 0; j < 6; j++)
	{	
		high_resolution_clock::time_point t1 = high_resolution_clock::now();       //My start clock
		for (int i = 1; i < count+1; i++) {a.prepend(i);}  
		                          //populate my dynamic array with append
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		a.delete_list();
	}
									//  APPEND     //
	outfile << "Append" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		for (int i = 1; i != count+1; i++) {b.append(i);}                            //populate my dynamic array with append
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
		
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		b.delete_list();
	}
	
									//  ADD AT I     //                 
	outfile << "Add at i" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		for (int i = 1; i != count; i++) {c.add_at_i(i,i);}                        	//populate my dynamic array with add at i
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
		
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		c.delete_list();
	}
											//  REVERSE		//
	outfile << "Reverse" << endl;	
	//count = 1;
	for (int j = 0; j < 6; j++)
	{	
		for (int i = 1; i < count+1; i++) { d.prepend(i);}  						//populate my dynamic array with append
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		d.reverse();									                       	//reverse
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
		
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		d.delete_list();
	}
	
								//  SHUFFLE		//
	outfile << "Shuffle" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		//e.delete_list();
		for (int i = 1; i < count+1; i++) {e.prepend(i);}  
		//e.display_all();   						//populate my dynamic array with append
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		e.random_shuffle();										                       	//reverse
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		e.delete_list();
	}
										//  Rotate		//
	outfile << "Rotate" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		//f.delete_list();	
		for (int i = 1; i < count+1; i++) {f.prepend(i);}     						//populate my dynamic array with append
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		f.rotate(12);									                       	//reverse
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time

													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		f.delete_list();
	}
	
	return 0;
}
