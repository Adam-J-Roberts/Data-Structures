#include <iostream>
#include <iomanip> 
#include <ctime>
#include <chrono>
#include <ratio>
#include <fstream>
#include "DynamicArray.cpp"


using namespace std::chrono;

int main()
{

	int count = 1;																//times function will get run
	
	ofstream outfile;                                                           //starting my off stream
	outfile.open ("project_34.txt");											//Creating file to save too


	DynamicArray<int> a;														//Innitializing Array								
											//  PREPEND     //
	outfile << "Prepend" << endl;	
	
	for (int j = 0; j < 6; j++)
	{	
		a.delete_array();
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		for (int i = 0; i != count; i++) {a.prepend(i);}                            //populate my dynamic array with append
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
		
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		
	}

											//  APPEND     //
	outfile << "Append" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		a.delete_array();
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		for (int i = 0; i != count; i++) {a.append(i);}                            //populate my dynamic array with append
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
		
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		
	}
	
										//  ADD AT I     //                 
	outfile << "Add at i" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		a.delete_array();
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		for (int i = 0; i != count; i++) {a.add_at_i(i,i);}                        	//populate my dynamic array with add at i
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
		
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		
	}	
		
										//  REVERSE		//
	outfile << "Reverse" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		a.delete_array();
		for (int i = 0; i != count; i++) {a.prepend(i);}     						//populate my dynamic array with append
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		a.reverse();										                       	//reverse
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
		
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		
	}
	
										//  SHUFFLE		//
	outfile << "Shuffle" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		a.delete_array();
		for (int i = 0; i != count; i++) {a.prepend(i);}     						//populate my dynamic array with append
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		a.random_shuffle();										                       	//reverse
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time
		
													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		
	}
											//  Rotate		//
	outfile << "Rotate" << endl;	
	count = 1;
	for (int j = 0; j < 6; j++)
	{	
		a.delete_array();	
		for (int i = 0; i != count; i++) {a.prepend(i);}     						//populate my dynamic array with append
		high_resolution_clock::time_point t1 = high_resolution_clock::now();        //My start clock
		a.rotate(12);										                       	//reverse
		high_resolution_clock::time_point t2 = high_resolution_clock::now();        //My end clock
		duration<double, milli> time_span = t2 - t1;                                //Start time minus finish time

													//What gets written to file
		outfile << "It took me " << time_span.count() << " seconds to run this " 
			    << count << " times." << endl;										//First test results
		count = (count * 10);
		
	}
	
	return 0;
}
